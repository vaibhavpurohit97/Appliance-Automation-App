package tanushree.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SecondActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_activity);

        final EditText editIp1 = (EditText)findViewById(R.id.ip2);
        Intent intent = getIntent();
        editIp1.setText(intent.getStringExtra("IP"));
        editIp1.setEnabled(false);

        Button btn1 = (Button) findViewById(R.id.device1);
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(SecondActivity.this, Connect1.class);
                myIntent.putExtra ( "IP2", editIp1.getText().toString() );
                SecondActivity.this.startActivity(myIntent);
            }
        });

        Button btn2 = (Button) findViewById(R.id.device2);
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(SecondActivity.this, Connect2.class);
                myIntent.putExtra ( "IP2", editIp1.getText().toString() );
                SecondActivity.this.startActivity(myIntent);
            }
        });

        Button btn3 = (Button) findViewById(R.id.device3);
        btn3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(SecondActivity.this, Connect3.class);
                myIntent.putExtra ( "IP2", editIp1.getText().toString() );
                SecondActivity.this.startActivity(myIntent);
            }
        });

        Button btn4 = (Button) findViewById(R.id.device4);
        btn4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(SecondActivity.this, Connect4.class);
                myIntent.putExtra ( "IP2", editIp1.getText().toString() );
                SecondActivity.this.startActivity(myIntent);
            }
        });

        Button btnGetStatus = (Button) findViewById(R.id.btnget);
        btnGetStatus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent myIntent = new Intent(SecondActivity.this, GetStatus.class);
                myIntent.putExtra ( "IP2", editIp1.getText().toString() );
                SecondActivity.this.startActivity(myIntent);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //infalte the menu. this adds items to the action bar if present
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
        /*MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.game_menu, menu);
        return true;*/

    }
    //Determines if action bar was selected . if true then do the corresponding actions
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        //handle presses on the action bar


        switch (item.getItemId()){

            case R.id.activity_settings:
                startActivity(new Intent(this,settings.class));
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

}
