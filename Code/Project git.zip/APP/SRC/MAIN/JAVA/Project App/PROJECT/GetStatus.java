package tanushree.project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class GetStatus extends AppCompatActivity {

    Button btnStatus;
    TextView textInfo1,tvsts;
    EditText editIp;

    ImageView imgd1, imgd2, imgd3, imgd4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_status1);

        imgd1 = (ImageView) findViewById(R.id.imgd1);
        imgd2 = (ImageView) findViewById(R.id.imgd2);
        imgd3 = (ImageView) findViewById(R.id.imgd3);
        imgd4 = (ImageView) findViewById(R.id.imgd4);

        btnStatus = (Button)findViewById(R.id.btnget);

        textInfo1 = (TextView)findViewById(R.id.textInfo1);
        tvsts = (TextView)findViewById(R.id.tvsts);

        editIp = (EditText)findViewById(R.id.ip);

        Bundle extras = getIntent().getExtras();
        editIp.setText(extras.getString("IP2"));
        editIp.setEnabled(false);

        btnStatus = (Button) findViewById(R.id.btnget);
        btnStatus.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                btnStatus.setEnabled(false);

                String serverStatus = editIp.getText().toString()+"/get_all";
                TaskEsp espStatus = new TaskEsp(serverStatus);
                espStatus.execute();
            }
        });
    }
    private class TaskEsp extends AsyncTask<Void, Void, String> {

        String server;

        TaskEsp(String server){
            this.server = server;
        }

        @Override
        protected String doInBackground(Void... params) {

            final String p = "http://"+server;

            runOnUiThread(new Runnable(){
                @Override
                public void run() {
                    textInfo1.setText(p);
                }
            });

            String serverResponse = "";

            //Using java.net.HttpURLConnection
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(p).openConnection());
                /*URL url = new URL(p);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.connect();*/
                if(httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {

                    InputStream inputStream = null;
                    inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader =
                            new BufferedReader(new InputStreamReader(inputStream));
                    serverResponse = bufferedReader.readLine();

                    inputStream.close();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
                serverResponse = e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                serverResponse = e.getMessage();
            }

            return serverResponse;
        }

        @Override
        protected void onPostExecute(String s)
        {
            tvsts.setText(s);
            //String s1,s2,s3,s4;
            //s1=s2=s3=s4=s;
            char check1;
            check1 = s.charAt(0);
            if(check1=='1')
            {
                imgd1.setImageResource(R.drawable.bulb_on);
            }
            if (check1=='0')
            {
                imgd1.setImageResource(R.drawable.bulb_off);
            }

            char check2;
            check2 = s.charAt(1);
            if(check2=='1')
            {
                imgd2.setImageResource(R.drawable.bulb_on);
            }
            if (check2=='0')
            {
                imgd2.setImageResource(R.drawable.bulb_off);
            }

            char check3;
            check3 = s.charAt(2);
            if(check3=='1')
            {
                imgd3.setImageResource(R.drawable.bulb_on);
            }
            if (check3=='0')
            {
                imgd3.setImageResource(R.drawable.bulb_off);
            }

            char check4;
            check4 = s.charAt(3);
            if(check4=='1')
            {
                imgd4.setImageResource(R.drawable.bulb_on);
            }
            if (check4=='0')
            {
                imgd4.setImageResource(R.drawable.bulb_off);
            }

            btnStatus.setEnabled(true);
        }
    }
}
