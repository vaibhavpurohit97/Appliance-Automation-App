package tanushree.project;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Howtouse extends AppCompatActivity {

    TextView tv1,tv2;
    Typeface tf1,tf2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_howtouse);

        tv1= (TextView)findViewById(R.id.howto);
        tv2= (TextView)findViewById(R.id.howtohead);

        tf1= Typeface.createFromAsset(getAssets(), "Roboto.ttf");
        tf2= Typeface.createFromAsset(getAssets(), "Lobster.otf");

        tv1.setTypeface(tf1);
        tv2.setTypeface(tf2);

    }
}
