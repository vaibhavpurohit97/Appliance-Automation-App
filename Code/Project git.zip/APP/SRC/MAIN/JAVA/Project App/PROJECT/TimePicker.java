package tanushree.project;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class TimePicker extends AppCompatActivity implements DatePickerDialog.OnDateSetListener,
        TimePickerDialog.OnTimeSetListener, AdapterView.OnItemSelectedListener {


    Button b_seton;
    TextView tv_result;
    Spinner spinner;
    //String defaultspinnertext=" Select Hours";
    int day, month, year, hour , minute;
    int dayFinal, monthFinal, yearFinal, hourFinal, minuteFinal;

    TextView tv1;
    Typeface tf1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_picker);

        //Font
        tv1= (TextView)findViewById(R.id.SetTime);

        tf1= Typeface.createFromAsset(getAssets(), "Roboto.ttf");

        tv1.setTypeface(tf1);

        b_seton = (Button) findViewById(R.id.Setontime);
        spinner= (Spinner) findViewById(R.id.timevalues);
        tv_result= (TextView) findViewById(R.id.Settime);

        ArrayAdapter adapter= ArrayAdapter.createFromResource(this,R.array.Hours,android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);



        b_seton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                Calendar c = Calendar.getInstance();
                year= c.get(Calendar.YEAR);
                month= c.get(Calendar.MONTH);
                day=c.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog= new DatePickerDialog(TimePicker.this,TimePicker.this,year,month,day);
                datePickerDialog.show();

            }
      });
    }


    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        yearFinal=i;
        monthFinal=i1+1;
        dayFinal=i2;

        Calendar c =Calendar.getInstance();
        hour=c.get(Calendar.HOUR_OF_DAY);
        minute=c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog;
        timePickerDialog = new TimePickerDialog(TimePicker.this, TimePicker.this,hour, minute, android.text.format.DateFormat.is24HourFormat(this));
        timePickerDialog.show();

    }

    @Override
    public void onTimeSet(android.widget.TimePicker timePicker, int i, int i1) {
        hourFinal=i;
        minuteFinal=i1;

        tv_result.setText("Year: "+yearFinal+ "\nMonth: "+monthFinal+ "\nDay: "+dayFinal+"\nHour"+hourFinal+"\nMinute"+minuteFinal);



    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        TextView text = (TextView)view;
        Toast.makeText(this,"You Selected " +text.getText()+ " hours", Toast.LENGTH_LONG).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
