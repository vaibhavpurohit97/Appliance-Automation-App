package tanushree.project;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class info extends AppCompatActivity {

    TextView tv1,tv2;
    Typeface tf1,tf2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        tv1= (TextView)findViewById(R.id.info2);
        tv2= (TextView)findViewById(R.id.info1);

        tf1= Typeface.createFromAsset(getAssets(), "Roboto.ttf");
        tf2= Typeface.createFromAsset(getAssets(), "Lobster.otf");

        tv1.setTypeface(tf1);
        tv2.setTypeface(tf2);
    }
}
