package tanushree.project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }

    public void HowtoUse ( View view){
        Intent intent = new Intent(this, Howtouse.class);
        startActivity(intent);
    }

    public void info (View view){
        Intent intent = new Intent(this, info.class);
        startActivity(intent);
    }
    public void Timepicker (View view){
        Intent intent = new Intent(this, TimePicker.class);
        startActivity(intent);
    }



}
